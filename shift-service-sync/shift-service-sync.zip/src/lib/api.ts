import { Shift, ServiceRequest, Employee, Invoice, PayrollEntry, DashboardStats } from './types';

// Base URL for the API - this should be an environment variable in production
const API_URL = 'http://localhost:8000';

// Helper function to get the authentication token
function getToken(): string | null {
  const token = localStorage.getItem('token');
  console.log('Retrieved token from localStorage:', token ? 'Token exists' : 'No token found');
  return token;
}

// Helper function for making API requests
export async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...options.headers,
  };

  // Convert any number IDs in the endpoint to strings
  const processedEndpoint = endpoint.replace(/\/(\d+)\//g, (match, id) => `/${id}/`);

  console.log(`Making API request to: ${API_URL}${processedEndpoint}`, {
    method: options.method || 'GET',
    headers: {
      ...headers,
      Authorization: headers.Authorization ? 'Bearer [REDACTED]' : undefined
    },
    hasBody: !!options.body
  });

  try {
    const response = await fetch(`${API_URL}${processedEndpoint}`, {
      ...options,
      headers,
    });

    console.log(`API response status: ${response.status}`, {
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries())
    });

    if (!response.ok) {
      let errorData;
      try {
        errorData = await response.json();
      } catch (e) {
        errorData = { detail: response.statusText };
      }
      
      console.error('API error response:', {
        status: response.status,
        statusText: response.statusText,
        errorData
      });

      // Create a more detailed error message
      let errorMessage = '';
      if (errorData.detail) {
        errorMessage = errorData.detail;
      } else if (errorData.message) {
        errorMessage = errorData.message;
      } else if (typeof errorData === 'string') {
        errorMessage = errorData;
      } else if (typeof errorData === 'object') {
        errorMessage = Object.entries(errorData)
          .map(([key, value]) => `${key}: ${value}`)
          .join(', ');
      } else {
        errorMessage = `API request failed with status ${response.status}: ${response.statusText}`;
      }
      
      const error = new Error(errorMessage);
      (error as any).status = response.status;
      (error as any).data = errorData;
      throw error;
    }

    const data = await response.json();
    console.log(`API response data for ${processedEndpoint}:`, data);
    return data;
  } catch (error) {
    console.error('API request failed:', {
      endpoint: processedEndpoint,
      error: error instanceof Error ? {
        message: error.message,
        stack: error.stack,
        status: (error as any).status,
        data: (error as any).data
      } : error
    });
    throw error;
  }
}

// API functions for shifts
export const shiftsApi = {
  getAll: () => apiRequest<Shift[]>('/planning/'),
  getById: (id: number) => apiRequest<Shift>(`/planning/${id}/`),
  create: (data: Omit<Shift, 'id'>) => apiRequest<Shift>('/planning/', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  update: (id: number, data: Partial<Shift>) => apiRequest<Shift>(`/planning/${id}/`, {
    method: 'PUT',
    body: JSON.stringify(data)
  }),
  delete: (id: number) => apiRequest<void>(`/planning/${id}/`, {
    method: 'DELETE'
  }),
  getMyShift: (id: number) => apiRequest<Shift>(`/planning/my-shifts/${id}/`)
};

// API functions for service requests
export const serviceRequestsApi = {
  getAll: () => apiRequest<ServiceRequest[]>('/dienstaanvragen/'),
  getMyRequests: () => apiRequest<ServiceRequest[]>('/dienstaanvragen/my-requests/'),
  getAvailableShifts: () => apiRequest<Shift[]>('/planning/available-shifts'),
  create: (data: Partial<ServiceRequest>) => 
    apiRequest<ServiceRequest>('/dienstaanvragen/', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<ServiceRequest>) =>
    apiRequest<ServiceRequest>(`/dienstaanvragen/${id}/`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    apiRequest<void>(`/dienstaanvragen/${id}/`, {
      method: 'DELETE',
    }),
  approve: (id: number) =>
    apiRequest<ServiceRequest>(`/dienstaanvragen/${id}/approve/`, {
      method: 'POST',
    }),
  reject: (id: number) =>
    apiRequest<ServiceRequest>(`/dienstaanvragen/${id}/reject/`, {
      method: 'POST',
    }),
};

// API functions for employees
export const employeesApi = {
  getAll: async () => {
    console.log('Fetching all employees...');
    const result = await apiRequest<Employee[]>('/medewerkers/');
    console.log('Employees fetched:', result);
    return result;
  },
  getById: (id: string) => apiRequest<Employee>(`/medewerkers/${id}`),
  create: (employee: Omit<Employee, 'id'>) =>
    apiRequest<Employee>('/medewerkers/', 'POST', employee),
  update: (id: string, employee: Partial<Employee>) =>
    apiRequest<Employee>(`/medewerkers/${id}`, 'PUT', employee),
  delete: (id: string) => apiRequest<void>(`/medewerkers/${id}`, 'DELETE'),
  getMyProfile: () => apiRequest<Employee>('/employee_profiles/my-profile'),
};

// API functions for invoices
export const invoicesApi = {
  getAll: () => apiRequest<Invoice[]>('/facturen/'),
  getById: (id: string) => apiRequest<Invoice>(`/facturen/${id}`),
  create: (invoice: {
    opdrachtgever_id: number;
    locatie: string;
    factuurdatum: string;
    bedrag: number;
    status: string;
    factuur_text: string;
  }) => apiRequest<Invoice>('/facturen/', {
    method: 'POST',
    body: JSON.stringify(invoice)
  }),
  update: (id: string, invoice: Partial<{
    opdrachtgever_id: number;
    locatie: string;
    factuurdatum: string;
    bedrag: number;
    status: string;
    factuur_text: string;
  }>) => apiRequest<Invoice>(`/facturen/${id}`, {
    method: 'PUT',
    body: JSON.stringify(invoice)
  }),
  delete: (id: string) => apiRequest<void>(`/facturen/${id}`, {
    method: 'DELETE'
  }),
  markAsPaid: (id: string) => apiRequest<Invoice>(`/facturen/${id}/mark-paid`, {
    method: 'POST'
  }),
  upload: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return apiRequest<string>('/facturen/upload', {
      method: 'POST',
      body: formData,
      headers: {
        Accept: 'application/json'
      }
    });
  },
  listUploads: () => apiRequest<string[]>('/facturen/uploads'),
  download: (filename: string) => apiRequest<Blob>(`/facturen/download/${filename}`, {
    headers: {
      Accept: 'application/pdf'
    }
  }),
  generateInvoice: (clientId: string, startDate: Date, endDate: Date) => {
    const params = new URLSearchParams({
      opdrachtgever_id: clientId,
      start_date: startDate.toISOString().split('T')[0],
      end_date: endDate.toISOString().split('T')[0]
    });
    return apiRequest<Invoice>(`/facturen/?${params.toString()}`, {
      method: 'POST'
    });
  }
};

// API functions for payroll
export const payrollApi = {
  getAll: (year?: number) => apiRequest<PayrollEntry[]>(`/verloning/${year ? `?year=${year}` : ''}`),
  export: (year: number) => apiRequest<Blob>(`/verloning/export?year=${year}`),
  getMyPayroll: (year?: number) => apiRequest<PayrollEntry[]>(`/verloning/my-payroll${year ? `?year=${year}` : ''}`),
  exportMyPayroll: (year: number) => apiRequest<Blob>(`/verloning/my-payroll/export?year=${year}`),
};

// API functions for dashboard
export const dashboardApi = {
  getStats: () => apiRequest<DashboardStats>('/dashboard/'),
  getEmployeeDashboard: () => apiRequest<EmployeeDashboardData>('/dashboard/employee'),
};

// API functions for users
export const usersApi = {
  getAll: () => apiRequest<User[]>('/users/'),
  getById: (id: string) => apiRequest<User>(`/users/${id}`),
  create: (user: Omit<User, 'id'>) => apiRequest<User>('/users/', {
    method: 'POST',
    body: JSON.stringify(user)
  }),
  update: (id: string, user: Partial<User>) => apiRequest<User>(`/users/${id}`, {
    method: 'PUT',
    body: JSON.stringify(user)
  }),
  delete: (id: string) => apiRequest<void>(`/users/${id}`, {
    method: 'DELETE'
  }),
  getCurrentUser: () => apiRequest<User>('/users/me'),
};

// API functions for roles
export const rolesApi = {
  getAll: () => apiRequest<Role[]>('/roles/'),
  create: (data: Partial<Role>) => 
    apiRequest<Role>('/roles/', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<Role>) =>
    apiRequest<Role>(`/roles/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    apiRequest<void>(`/roles/${id}/`, {
      method: 'DELETE',
    }),
};

// API functions for opdrachtgevers (clients)
export const opdrachtgeversApi = {
  getAll: () => apiRequest<Opdrachtgever[]>('/opdrachtgevers/'),
  getById: (id: string) => apiRequest<Opdrachtgever>(`/opdrachtgevers/${id}`),
  create: (opdrachtgever: Omit<Opdrachtgever, 'id'>) =>
    apiRequest<Opdrachtgever>('/opdrachtgevers/', {
      method: 'POST',
      body: JSON.stringify(opdrachtgever)
    }),
  update: (id: string, opdrachtgever: Partial<Opdrachtgever>) =>
    apiRequest<Opdrachtgever>(`/opdrachtgevers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(opdrachtgever)
    }),
  delete: (id: string) => apiRequest<void>(`/opdrachtgevers/${id}`, {
    method: 'DELETE'
  }),
};

// Add User interface
export interface User {
  id: number;
  username: string;
  email: string;
  full_name: string;
  roles: string[];
}

// Add Role interface
export interface Role {
  id: number;
  name: string;
  description: string;
  permissions: string[];
}

// Add EmployeeDashboardData interface
export interface EmployeeDashboardData {
  shifts: Shift[];
  service_requests: ServiceRequest[];
  payroll: PayrollEntry;
  profile: Employee;
}