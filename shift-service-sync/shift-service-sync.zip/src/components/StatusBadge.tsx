import React from 'react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

type StatusType = 'open' | 'pending' | 'approved' | 'rejected' | 'canceled' | 'completed' | 'draft';

interface StatusBadgeProps {
  status: StatusType;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const statusStyles = {
    open: 'bg-green-100 text-green-800 hover:bg-green-100',
    pending: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100',
    approved: 'bg-green-100 text-green-800 hover:bg-green-100',
    rejected: 'bg-red-100 text-red-800 hover:bg-red-100',
    canceled: 'bg-gray-100 text-gray-800 hover:bg-gray-100',
    completed: 'bg-blue-100 text-blue-800 hover:bg-blue-100',
    draft: 'bg-gray-100 text-gray-800 hover:bg-gray-100',
  };

  return (
    <Badge 
      variant="outline" 
      className={cn(
        'font-medium',
        statusStyles[status],
        className
      )}
    >
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
}
