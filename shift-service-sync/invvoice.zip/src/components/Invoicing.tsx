import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Shift, Employee } from '../lib/types';

// ... existing code ... 