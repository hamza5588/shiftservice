import React from 'react';
import { Invoice } from '@/lib/types';

interface InvoiceTemplateProps {
  invoice: Invoice;
}

export const InvoiceTemplate: React.FC<InvoiceTemplateProps> = ({ invoice }) => {
  // Helper function to safely format currency
  const formatCurrency = (amount: number | undefined) => {
    return `€ ${(amount || 0).toFixed(2)}`;
  };

  // Helper function to safely format hours
  const formatHours = (hours: number | undefined) => {
    return `${(hours || 0).toFixed(1)}`;
  };

  // Helper function to format date
  const formatDate = (date: string | undefined) => {
    if (!date) return '';
    const [year, month, day] = date.split('-');
    return `${day}-${month}-${year}`;
  };

  // Parse the factuur_text to get the breakdown details
  const parseFactuurText = (text: string) => {
    const lines = text.split('\n');
    const breakdown: Record<string, { hours: number; rate: number; total: number }> = {};
    let subtotal = 0;
    let vatAmount = 0;
    let total = 0;
    
    lines.forEach(line => {
      if (line.includes(':')) {
        const [period, details] = line.split(':');
        const trimmedPeriod = period.toLowerCase().trim();
        
        // Handle summary lines
        if (trimmedPeriod === 'subtotal') {
          const amount = details.match(/€([\d.]+)/)?.[1];
          if (amount) subtotal = parseFloat(amount);
          return;
        }
        if (trimmedPeriod === 'vat' || trimmedPeriod === 'btw') {
          const amount = details.match(/€([\d.]+)/)?.[1];
          if (amount) vatAmount = parseFloat(amount);
          return;
        }
        if (trimmedPeriod === 'total') {
          const amount = details.match(/€([\d.]+)/)?.[1];
          if (amount) total = parseFloat(amount);
          return;
        }
        
        // Extract hours, rate, and total using regex
        const matches = details.match(/([\d.]+)h x €([\d.]+) = €([\d.]+)/);
        if (matches) {
          const [_, hours, rate, total] = matches;
          breakdown[trimmedPeriod] = {
            hours: parseFloat(hours),
            rate: parseFloat(rate),
            total: parseFloat(total)
          };
        }
      }
    });

    // If VAT amount is 0 but we have total and subtotal, calculate VAT
    if (vatAmount === 0 && total > 0 && subtotal > 0) {
      vatAmount = total - subtotal;
    }
    
    return { breakdown, subtotal, vatAmount, total };
  };

  const { breakdown, subtotal, vatAmount, total } = parseFactuurText(invoice.factuur_text);

  return (
    <div className="bg-white p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-6">FACTUUR</h1>
          <div className="grid grid-cols-2 gap-x-8">
            <div>
              <h2 className="font-bold">DATUM</h2>
              <p>{formatDate(invoice.factuurdatum)}</p>
            </div>
            <div>
              <h2 className="font-bold">FACTUURNUMMER</h2>
              <p>{invoice.id || '-'}</p>
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="bg-[#F4B740] p-4 inline-block">
            <h2 className="text-2xl font-bold text-white">Secufy</h2>
          </div>
          <div className="mt-4 text-sm">
            <p>94486786</p>
            <p>Soetendalseweg 32c</p>
            <p>3036ER Rotterdam</p>
            <p>0685455793</p>
            <p>vraagje@secufy.nl</p>
          </div>
        </div>
      </div>

      {/* Client Info */}
      <div className="mb-8">
        <h2 className="font-bold mb-2">FACTUUR AAN:</h2>
        <p>{invoice.client_name || '-'}</p>
        <p>{invoice.locatie || '-'}</p>
      </div>

      {/* Invoice Table */}
      <table className="w-full mb-8">
        <thead>
          <tr className="border-b">
            <th className="text-left py-2">UREN</th>
            <th className="text-left py-2">LOCATIE</th>
            <th className="text-left py-2">UREN</th>
            <th className="text-left py-2">DATUM</th>
            <th className="text-right py-2">TOTAAL</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(breakdown)
            .filter(([_, data]) => data.hours > 0)
            .map(([period, data], index) => (
              <tr key={index} className="border-b">
                <td className="py-2">{formatHours(data.hours)}</td>
                <td className="py-2">{invoice.locatie || '-'}</td>
                <td className="py-2">{formatCurrency(data.rate)}</td>
                <td className="py-2">{formatDate(invoice.factuurdatum)}</td>
                <td className="py-2 text-right">{formatCurrency(data.total)}</td>
              </tr>
            ))}
        </tbody>
      </table>

      {/* Totals */}
      <div className="flex justify-end mb-8">
        <div className="w-64">
          <div className="flex justify-between mb-2">
            <span>Subtotaal</span>
            <span>{formatCurrency(subtotal)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Btw ({invoice.vat_rate || 21}%)</span>
            <span>{formatCurrency(vatAmount)}</span>
          </div>
          <div className="flex justify-between font-bold">
            <span>Totaal</span>
            <span>{formatCurrency(total)}</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center mt-12">
        <h3 className="font-bold mb-2">BEDANKT VOOR UW KLANDIZIE</h3>
        <p className="text-sm">Alle bedragen gelieve over te maken op rekeningnummer NL11 ABNA 0137 7274 61</p>
      </div>
    </div>
  );
};

export default InvoiceTemplate; 