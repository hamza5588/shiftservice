import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { invoicesApi, opdrachtgeversApi, locationsApi, shiftsApi } from '@/lib/api';
import { Invoice } from '@/lib/types';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, FileText, Download, Eye, Calendar, Trash2 } from 'lucide-react';
import { useState, useMemo } from 'react';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { DatePicker } from '@/components/ui/date-picker';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import InvoiceTemplate from '@/components/InvoiceTemplate';
import { Spinner } from '@/components/ui/spinner';

// Rate configuration
const defaultRates = {
  base: 20.00,     // Base rate per hour
  evening: 22.00,  // Base + 10% (20.00 + 2.00)
  night: 24.00,    // Base + 20% (20.00 + 4.00)
  weekend: 27.00,  // Base + 35% (20.00 + 7.00)
  holiday: 30.00,  // Base + 50% (20.00 + 10.00)
  new_year_eve: 40.00 // Base + 100% (20.00 + 20.00)
};

// Define types for our data
interface Shift {
  id: number;
  shift_date: string;
  start_time: string;
  end_time: string;
  location_id: number;
  employee_id: string;
  location?: string;
  location_details?: {
    id: number;
    naam: string;
    adres: string;
    stad: string;
    provincie: string | null;
  };
  status?: string;
  assigned_by_admin?: string | null;
  reiskilometers?: number | null;
  required_profile?: string;
  titel?: string;
  adres?: string;
  provincie?: string;
  stad?: string;
}

interface Location {
  id: number;
  naam: string;
  opdrachtgever_id: number;
  adres: string;
  stad: string;
  postcode: string;
  provincie?: string;
  created_at?: string;
  updated_at?: string;
}

export default function Invoicing() {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewInvoiceId, setViewInvoiceId] = useState<number | null>(null);
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<string>('');
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();
  const [rates, setRates] = useState<typeof defaultRates>(defaultRates);
  const [vatRate, setVatRate] = useState(21);
  const [paymentTerms, setPaymentTerms] = useState(14);
  const { toast } = useToast();

  // Add delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) => invoicesApi.delete(id),
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Invoice deleted successfully',
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to delete invoice',
        variant: 'destructive',
      });
    },
  });

  // Add confirmation dialog state
  const [invoiceToDelete, setInvoiceToDelete] = useState<number | null>(null);

  // Query for invoices
  const { data: invoices, isLoading, refetch } = useQuery({
    queryKey: ['invoices'],
    queryFn: invoicesApi.getAll,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 0
  });

  // Query for clients
  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: opdrachtgeversApi.getAll,
  });

  // Query for locations
  const { data: locations } = useQuery({
    queryKey: ['locations'],
    queryFn: locationsApi.getAll,
  });

  // Query for shifts
  const { data: shifts } = useQuery({
    queryKey: ['shifts'],
    queryFn: shiftsApi.getAll,
  });

  // Calculate hours from shifts
  const calculateHoursFromShifts = (clientId: string, locationId: string, startDate: Date, endDate: Date) => {
    // Use current rates or default rates if not available
    const currentRates = rates || defaultRates;
    console.log('Current rates:', currentRates);
    console.log('Parameters:', { clientId, locationId, startDate, endDate });

    if (!shifts) {
      console.warn('No shifts data available');
      return {
        day: { hours: 0, rate: currentRates.base, total: 0 },
        evening: { hours: 0, rate: currentRates.evening, total: 0 },
        night: { hours: 0, rate: currentRates.night, total: 0 },
        weekend: { hours: 0, rate: currentRates.weekend, total: 0 },
        holiday: { hours: 0, rate: currentRates.holiday, total: 0 },
        new_year_eve: { hours: 0, rate: currentRates.new_year_eve, total: 0 }
      };
    }

    console.log('Total shifts before filtering:', shifts.length);
    console.log('Sample shift data:', shifts[0]);

    // Helper function to parse date string in YYYY-MM-DD format
    const parseDateString = (dateStr: string) => {
      const [year, month, day] = dateStr.split('-').map(Number);
      return new Date(year, month - 1, day);
    };

    // Helper function to normalize dates for comparison
    const normalizeDate = (date: Date) => {
      const normalized = new Date(date);
      normalized.setHours(0, 0, 0, 0);
      return normalized;
    };

    // Normalize the input dates
    const normalizedStartDate = normalizeDate(startDate);
    const normalizedEndDate = normalizeDate(endDate);
    // Add one day to end date to include the full end date
    normalizedEndDate.setDate(normalizedEndDate.getDate() + 1);

    // Filter shifts based on client, location and date range
    const filteredShifts = shifts.filter(shift => {
      const shiftDate = normalizeDate(parseDateString(shift.shift_date));
      const matchesLocation = shift.location_id === parseInt(locationId);
      const isInDateRange = shiftDate >= normalizedStartDate && shiftDate < normalizedEndDate;
      
      console.log('Shift filtering:', {
        shiftId: shift.id,
        shiftDate: shift.shift_date,
        parsedShiftDate: shiftDate,
        normalizedStartDate,
        normalizedEndDate,
        locationId: shift.location_id,
        expectedLocationId: parseInt(locationId),
        matchesLocation,
        isInDateRange
      });

      return matchesLocation && isInDateRange;
    });

    console.log('Filtered shifts count:', filteredShifts.length);
    console.log('Filtered shifts:', filteredShifts);

    const breakdown = {
      day: { hours: 0, rate: currentRates.base, total: 0 },
      evening: { hours: 0, rate: currentRates.evening, total: 0 },
      night: { hours: 0, rate: currentRates.night, total: 0 },
      weekend: { hours: 0, rate: currentRates.weekend, total: 0 },
      holiday: { hours: 0, rate: currentRates.holiday, total: 0 },
      new_year_eve: { hours: 0, rate: currentRates.new_year_eve, total: 0 }
    };

    filteredShifts.forEach(shift => {
      const shiftDate = parseDateString(shift.shift_date);
      console.log('Processing shift:', {
        shiftId: shift.id,
        date: shift.shift_date,
        startTime: shift.start_time,
        endTime: shift.end_time
      });
      
      // Convert HH:mm format to Date objects for calculation
      const [startHours, startMinutes] = shift.start_time.split(':').map(Number);
      const [endHours, endMinutes] = shift.end_time.split(':').map(Number);
      
      const startTime = new Date(shiftDate);
      startTime.setHours(startHours, startMinutes, 0);
      
      const endTime = new Date(shiftDate);
      endTime.setHours(endHours, endMinutes, 0);
      
      // If end time is before start time, it means the shift ends the next day
      if (endTime < startTime) {
        endTime.setDate(endTime.getDate() + 1);
      }
      
      // Calculate total hours for this shift
      const hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
      console.log('Calculated hours:', {
        shiftId: shift.id,
        startTime: startTime.toISOString(),
        endTime: endTime.toISOString(),
        totalHours: hours
      });

      const isWeekend = shiftDate.getDay() === 0 || shiftDate.getDay() === 6;
      const isNewYearEve = shiftDate.getMonth() === 11 && shiftDate.getDate() === 31;
      
      console.log('Shift categorization:', {
        shiftId: shift.id,
        isWeekend,
        isNewYearEve,
        startHour: startHours
      });

      // Determine the rate category based on time and date
      if (isNewYearEve && startHours >= 16) {
        breakdown.new_year_eve.hours += hours;
        breakdown.new_year_eve.total += hours * currentRates.new_year_eve;
        console.log('Added to New Year\'s Eve:', { hours, rate: currentRates.new_year_eve });
      } else if (isWeekend) {
        breakdown.weekend.hours += hours;
        breakdown.weekend.total += hours * currentRates.weekend;
        console.log('Added to Weekend:', { hours, rate: currentRates.weekend });
      } else {
        // Regular day categorization
        if (startHours >= 22 || startHours < 6) {
          // Night hours (22:00 - 06:00)
          breakdown.night.hours += hours;
          breakdown.night.total += hours * currentRates.night;
          console.log('Added to Night:', { hours, rate: currentRates.night });
        } else if (startHours >= 18 && startHours < 22) {
          // Evening hours (18:00 - 22:00)
          breakdown.evening.hours += hours;
          breakdown.evening.total += hours * currentRates.evening;
          console.log('Added to Evening:', { hours, rate: currentRates.evening });
        } else {
          // Day hours (06:00 - 18:00)
          breakdown.day.hours += hours;
          breakdown.day.total += hours * currentRates.base;
          console.log('Added to Day:', { hours, rate: currentRates.base });
        }
      }
    });

    console.log('Final breakdown:', breakdown);
    
    // Calculate totals
    const totalHours = Object.values(breakdown).reduce((sum, { hours }) => sum + hours, 0);
    const totalAmount = Object.values(breakdown).reduce((sum, { total }) => sum + total, 0);
    
    console.log('Totals:', {
      totalHours,
      totalAmount,
      vatAmount: totalAmount * (vatRate / 100),
      finalTotal: totalAmount * (1 + vatRate / 100)
    });

    return breakdown;
  };

  // Get the viewed invoice with proper type checking
  const viewedInvoice = useMemo(() => {
    if (!viewInvoiceId || !invoices) return null;
    const invoice = invoices.find(invoice => invoice.id === viewInvoiceId);
    console.log('Finding invoice:', { viewInvoiceId, invoice, allInvoices: invoices });
    return invoice;
  }, [viewInvoiceId, invoices]);

  // Mutation for generating invoice
  const generateInvoiceMutation = useMutation({
    mutationFn: async () => {
      if (!selectedClient || !selectedLocation || !startDate || !endDate) {
        throw new Error('Please fill in all required fields');
      }
      if (endDate < startDate) {
        throw new Error('End date must be after start date');
      }

      // Calculate hours and amounts
      const breakdown = calculateHoursFromShifts(selectedClient, selectedLocation, startDate, endDate);
      console.log('Calculated breakdown:', breakdown);

      const subtotal = Object.values(breakdown).reduce((sum, item) => sum + item.total, 0);
      const vatAmount = subtotal * (vatRate / 100);
      const totalAmount = subtotal + vatAmount;

      // Get client and location details
      const client = clients?.find(c => c.id.toString() === selectedClient);
      const location = locations?.find(l => l.id.toString() === selectedLocation);

      if (!client || !location) {
        throw new Error('Client or location not found');
      }

      // Create invoice dates and number
      const issueDate = new Date();
      const dueDate = new Date();
      dueDate.setDate(issueDate.getDate() + paymentTerms);
      const invoiceNumber = `${issueDate.getFullYear()}${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`;

      // Create the invoice with all necessary fields
      const response = await invoicesApi.create({
        opdrachtgever_id: parseInt(selectedClient),
        locatie: location.naam,
        factuurdatum: issueDate.toISOString().split('T')[0],
        bedrag: totalAmount,
        status: 'open',
        factuur_text: [
          'Invoice details:',
          `Day: ${breakdown.day.hours.toFixed(1)}h x €${breakdown.day.rate.toFixed(2)} = €${breakdown.day.total.toFixed(2)}`,
          `Evening: ${breakdown.evening.hours.toFixed(1)}h x €${breakdown.evening.rate.toFixed(2)} = €${breakdown.evening.total.toFixed(2)}`,
          `Night: ${breakdown.night.hours.toFixed(1)}h x €${breakdown.night.rate.toFixed(2)} = €${breakdown.night.total.toFixed(2)}`,
          `Weekend: ${breakdown.weekend.hours.toFixed(1)}h x €${breakdown.weekend.rate.toFixed(2)} = €${breakdown.weekend.total.toFixed(2)}`,
          `Holiday: ${breakdown.holiday.hours.toFixed(1)}h x €${breakdown.holiday.rate.toFixed(2)} = €${breakdown.holiday.total.toFixed(2)}`,
          `New Year's Eve: ${breakdown.new_year_eve.hours.toFixed(1)}h x €${breakdown.new_year_eve.rate.toFixed(2)} = €${breakdown.new_year_eve.total.toFixed(2)}`,
          '',
          `Subtotal: €${subtotal.toFixed(2)}`,
          `VAT (${vatRate}%): €${vatAmount.toFixed(2)}`,
          `Total: €${totalAmount.toFixed(2)}`
        ].join('\n'),
        invoice_number: invoiceNumber,
        client_name: client.naam,
        client_address: client.adres,
        client_postal_code: client.postcode,
        client_city: client.stad,
        client_phone: client.telefoon,
        client_email: client.email,
        issue_date: issueDate.toISOString().split('T')[0],
        due_date: dueDate.toISOString().split('T')[0],
        total_amount: totalAmount,
        vat_amount: vatAmount,
        subtotal: subtotal,
        breakdown: breakdown
      });

      console.log('Created invoice:', response);
      return response;
    },
    onSuccess: async (data) => {
      toast({
        title: 'Success',
        description: 'Invoice generated successfully',
      });
      setIsGenerateDialogOpen(false);
      await refetch(); // Wait for refetch to complete
      setTimeout(() => {
        setViewInvoiceId(data.id); // Set the view invoice ID after a small delay
      }, 100);
    },
    onError: (error) => {
      console.error('Invoice generation error:', error);
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const filteredInvoices = invoices?.filter(invoice => {
    return searchQuery === '' || 
      invoice.client_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.invoice_number?.toLowerCase().includes(searchQuery.toLowerCase());
  }) || [];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('nl-NL', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatHours = (hours: number) => {
    return hours.toFixed(2);
  };

  // Update the input handlers to safely handle rate changes
  const handleRateChange = (rateType: keyof typeof defaultRates, value: string) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      setRates(prev => ({
        ...prev,
        [rateType]: numValue
      }));
    }
  };

  // Add these helper functions at the top of the file
  const formatDate = (dateString?: string | null) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date.getTime()) 
      ? date.toLocaleDateString('nl-NL', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit'
        })
      : '-';
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="page-title m-0">Invoicing</h1>
        
        <Dialog open={isGenerateDialogOpen} onOpenChange={setIsGenerateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" /> Generate Invoice
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Generate New Invoice</DialogTitle>
              <DialogDescription>
                Generate an invoice for a specific client, location, and date range.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="client">Client</Label>
                <Select value={selectedClient} onValueChange={setSelectedClient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients?.map((client) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.naam}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="location">Location</Label>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations?.map((location) => (
                      <SelectItem key={location.id} value={location.id.toString()}>
                        {location.naam}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Start Date</Label>
                  <DatePicker
                    date={startDate}
                    setDate={setStartDate}
                  />
                </div>
                <div className="grid gap-2">
                  <Label>End Date</Label>
                  <DatePicker
                    date={endDate}
                    setDate={setEndDate}
                  />
                </div>
              </div>

              <div className="border-t pt-4 mt-2">
                <h4 className="font-medium mb-3">Hourly Rates</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label>Day Rate (€)</Label>
                    <Input
                      type="number"
                      value={rates?.base || 20}
                      onChange={(e) => handleRateChange('base', e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Evening Rate (€)</Label>
                    <Input
                      type="number"
                      value={rates?.evening || 22}
                      onChange={(e) => handleRateChange('evening', e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Night Rate (€)</Label>
                    <Input
                      type="number"
                      value={rates?.night || 24}
                      onChange={(e) => handleRateChange('night', e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Weekend Rate (€)</Label>
                    <Input
                      type="number"
                      value={rates?.weekend || 27}
                      onChange={(e) => handleRateChange('weekend', e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Holiday Rate (€)</Label>
                    <Input
                      type="number"
                      value={rates?.holiday || 30}
                      onChange={(e) => handleRateChange('holiday', e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>New Year's Eve Rate (€)</Label>
                    <Input
                      type="number"
                      value={rates?.new_year_eve || 40}
                      onChange={(e) => handleRateChange('new_year_eve', e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="border-t pt-4 mt-2">
                <h4 className="font-medium mb-3">Additional Settings</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label>VAT Rate (%)</Label>
                    <Input
                      type="number"
                      value={vatRate}
                      onChange={(e) => setVatRate(parseFloat(e.target.value))}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Payment Terms (days)</Label>
                    <Input
                      type="number"
                      value={paymentTerms}
                      onChange={(e) => setPaymentTerms(parseInt(e.target.value))}
                    />
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={() => generateInvoiceMutation.mutate()}
                disabled={generateInvoiceMutation.isPending}
              >
                {generateInvoiceMutation.isPending ? 'Generating...' : 'Generate Invoice'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search invoices..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-card rounded-md border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice Number</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Issue Date</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              // Loading state
              [...Array(3)].map((_, i) => (
                <TableRow key={i}>
                  {[...Array(7)].map((_, j) => (
                    <TableCell key={j}>
                      <div className="h-5 bg-muted animate-pulse rounded"></div>
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : filteredInvoices.length > 0 ? (
              filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell>
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                      {invoice.invoice_number || invoice.id}
                    </div>
                  </TableCell>
                  <TableCell>{invoice.client_name || invoice.locatie || '-'}</TableCell>
                  <TableCell>{formatDate(invoice.factuurdatum || invoice.issue_date)}</TableCell>
                  <TableCell>{formatDate(invoice.due_date)}</TableCell>
                  <TableCell>{formatCurrency(invoice.bedrag || invoice.total_amount || 0)}</TableCell>
                  <TableCell>
                    <StatusBadge status={invoice.status || 'open'} />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => setViewInvoiceId(invoice.id)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => setInvoiceToDelete(invoice.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center h-32">
                  No invoices found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Invoice Dialog */}
      <Dialog open={viewInvoiceId !== null} onOpenChange={(open) => {
        if (!open) {
          setViewInvoiceId(null);
        }
      }}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>Invoice {viewedInvoice?.invoice_number}</DialogTitle>
          </DialogHeader>

          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <Spinner className="w-8 h-8" />
            </div>
          ) : viewedInvoice ? (
            <div className="space-y-6">
              {console.log('Viewed Invoice Data:', viewedInvoice)}
              <InvoiceTemplate invoice={viewedInvoice} />
            </div>
          ) : (
            <div className="text-center p-8 text-muted-foreground">
              Invoice not found
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add confirmation dialog for delete */}
      <Dialog open={invoiceToDelete !== null} onOpenChange={(open) => {
        if (!open) setInvoiceToDelete(null);
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Invoice</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this invoice? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setInvoiceToDelete(null)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (invoiceToDelete) {
                  deleteMutation.mutate(invoiceToDelete);
                  setInvoiceToDelete(null);
                }
              }}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
