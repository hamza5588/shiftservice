import { LocationRatesApi } from './locationRatesApi';
import { locationsApi } from './locationsApi';

// Create and export a single instance
export const locationRatesApi = new LocationRatesApi();
export { locationsApi }; 