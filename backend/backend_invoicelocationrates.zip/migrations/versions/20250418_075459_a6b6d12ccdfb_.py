"""empty message

Revision ID: a6b6d12ccdfb
Revises: 20250418075723
Create Date: 2025-04-18 07:54:59.764197+00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a6b6d12ccdfb'
down_revision = '20250418075723'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass 