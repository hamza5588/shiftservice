from fastapi import APIRouter, HTTPException, Depends, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import List, Optional
from datetime import date
import os
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from auth import require_roles, get_current_user

router = APIRouter(
    prefix="/facturen",
    tags=["facturen"]
)

UPLOAD_FOLDER = "uploaded_facturen"

# Zorg ervoor dat de map bestaat
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


class Factuur(BaseModel):
    id: int = 0  # Wordt automatisch ingesteld bij creatie
    opdrachtgever_id: int  # Koppeling aan de opdrachtgever (bijv. 1)
    opdrachtgever_naam: str  # Naam van de opdrachtgever
    factuurnummer: Optional[str] = None  # Factuurnummer in formaat [YEAR][CLIENT NUMBER][INVOICE COUNT]-[CLIENT DIGIT]
    locatie: str
    factuurdatum: date
    bedrag: float
    status: str  # Bijvoorbeeld "open", "betaald", "herinnering14", "herinnering30"
    factuur_text: Optional[str] = None  # Geïntegreerde sjabloon-output


fake_facturen_db = []
next_factuur_id = 1


@router.get("/", response_model=List[Factuur])
async def get_facturen(current_user: dict = Depends(require_roles(["boekhouding", "admin", "planner"]))):
    """Haal alle facturen op."""
    return fake_facturen_db


@router.get("/{factuur_id}", response_model=Factuur)
async def get_factuur(factuur_id: int, current_user: dict = Depends(require_roles(["boekhouding", "admin", "planner"]))):
    for factuur in fake_facturen_db:
        if factuur["id"] == factuur_id:
            return factuur
    raise HTTPException(status_code=404, detail="Factuur niet gevonden")


def generate_invoice_number(opdrachtgever_id: int, opdrachtgever_naam: str, existing_invoices: List[Factuur]) -> str:
    """Generate invoice number in format: [YEAR][CLIENT NUMBER][INVOICE COUNT]-[CLIENT DIGIT]"""
    year = date.today().year
    client_number = str(opdrachtgever_id).zfill(4)  # Pad with zeros to 4 digits
    
    # Get the last invoice number for this client to increment the count
    last_invoice = max(
        [int(inv["factuurnummer"].split('-')[0][8:]) for inv in existing_invoices 
         if "factuurnummer" in inv and inv["factuurnummer"].startswith(f"{year}{client_number}")],
        default=0
    )
    next_count = str(last_invoice + 1).zfill(3)
    
    # Get first 3 letters of client name for client digit
    client_digit = opdrachtgever_naam[:3].upper()
    
    return f"{year}{client_number}{next_count}-{client_digit}"


@router.post("/", response_model=Factuur, status_code=201)
async def create_factuur(factuur: Factuur, current_user: dict = Depends(require_roles(["boekhouding", "admin", "planner"]))):
    global next_factuur_id
    factuur_dict = factuur.dict()
    factuur_dict["id"] = next_factuur_id
    next_factuur_id += 1
    
    # Generate invoice number
    factuur_dict["factuurnummer"] = generate_invoice_number(
        factuur_dict["opdrachtgever_id"],
        factuur_dict["opdrachtgever_naam"],
        fake_facturen_db
    )
    
    fake_facturen_db.append(factuur_dict)
    return factuur_dict


@router.put("/{factuur_id}", response_model=Factuur)
async def update_factuur(factuur_id: int, factuur: Factuur, current_user: dict = Depends(require_roles(["boekhouding", "admin"]))):
    for index, existing_factuur in enumerate(fake_facturen_db):
        if existing_factuur["id"] == factuur_id:
            updated_factuur = factuur.dict()
            updated_factuur["id"] = factuur_id
            fake_facturen_db[index] = updated_factuur
            return updated_factuur
    raise HTTPException(status_code=404, detail="Factuur niet gevonden")


@router.delete("/{factuur_id}", response_model=Factuur)
async def delete_factuur(factuur_id: int, current_user: dict = Depends(require_roles(["boekhouding", "admin"]))):
    for index, factuur in enumerate(fake_facturen_db):
        if factuur["id"] == factuur_id:
            return fake_facturen_db.pop(index)
    raise HTTPException(status_code=404, detail="Factuur niet gevonden")


@router.post("/{factuur_id}/mark-paid", response_model=Factuur)
async def mark_factuur_as_paid(factuur_id: int, current_user: dict = Depends(require_roles(["boekhouding", "admin"]))):
    for factuur in fake_facturen_db:
        if factuur["id"] == factuur_id:
            factuur["status"] = "betaald"
            return factuur
    raise HTTPException(status_code=404, detail="Factuur niet gevonden")


### ✅ **Nieuwe functionaliteiten: Facturen Upload & Download**

@router.post("/upload")
async def upload_factuur(file: UploadFile = File(...), current_user: dict = Depends(require_roles(["admin", "boekhouding"]))):
    """
    Admins en Boekhouding kunnen facturen uploaden.
    De bestandsnaam moet het klantnummer of personeelsnummer bevatten.
    """
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    with open(file_path, "wb") as buffer:
        buffer.write(file.file.read())

    return {"message": f"Factuur {file.filename} geüpload"}


@router.get("/uploads")
async def list_uploaded_facturen(current_user: dict = Depends(require_roles(["admin", "boekhouding"]))):
    """
    Geeft een lijst van alle geüploade facturen terug.
    """
    files = os.listdir(UPLOAD_FOLDER)
    return {"facturen": files}


@router.get("/download/{filename}")
async def download_factuur(filename: str, current_user: dict = Depends(get_current_user)):
    """
    Opdrachtgevers en medewerkers kunnen hun eigen facturen downloaden.
    Admins en Boekhouding kunnen alle facturen downloaden.
    """
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Factuur niet gevonden")

    # Controleer of de gebruiker toegang heeft tot dit bestand
    if current_user["role"] not in ["admin", "boekhouding"]:
        if not filename.startswith(str(current_user["username"])):
            raise HTTPException(status_code=403, detail="Geen toegang tot deze factuur")

    return FileResponse(file_path, media_type='application/pdf', filename=filename)


@router.get("/pdf-export/facturen")
async def export_invoices_pdf(current_user: dict = Depends(require_roles(["boekhouding", "admin", "planner"]))):
    """Generate a PDF document containing all invoice details."""
    try:
        # Create a buffer to store the PDF
        buffer = io.BytesIO()
        
        # Create the PDF object
        p = canvas.Canvas(buffer, pagesize=A4)
        
        # Set up the PDF
        p.setTitle("Facturen Overzicht")
        p.setFont("Helvetica-Bold", 16)
        p.drawString(50, 800, "Facturen Overzicht")
        p.setFont("Helvetica", 12)
        
        # Create table data
        data = [["Factuurnummer", "Klant", "Datum", "Bedrag", "Status"]]
        
        for factuur in fake_facturen_db:
            data.append([
                factuur.get("factuurnummer", "-"),
                factuur.get("opdrachtgever_naam", "-"),
                factuur.get("factuurdatum", "-"),
                f"€{factuur.get('bedrag', 0):.2f}",
                factuur.get("status", "-")
            ])
        
        # Create table
        table = Table(data)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 12),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        # Draw the table
        table.wrapOn(p, 400, 600)
        table.drawOn(p, 50, 600)
        
        # Save the PDF
        p.showPage()
        p.save()
        
        # Reset buffer position
        buffer.seek(0)
        
        # Return the PDF as a streaming response
        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={
                "Content-Disposition": "attachment; filename=facturen_overzicht.pdf"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{factuur_id}/download")
async def download_factuur(factuur_id: int, current_user: dict = Depends(get_current_user)):
    """Download a single invoice as PDF."""
    try:
        # Find the invoice
        factuur = next((f for f in fake_facturen_db if f["id"] == factuur_id), None)
        if not factuur:
            raise HTTPException(status_code=404, detail="Factuur niet gevonden")

        # Create a buffer to store the PDF
        buffer = io.BytesIO()
        
        # Create the PDF object with A4 size
        p = canvas.Canvas(buffer, pagesize=A4)
        width, height = A4

        # Add beige background for bottom part (starts from middle of the page)
        p.setFillColor(colors.HexColor('#E8D5C4'))  # Light beige color
        p.rect(0, 0, width, height/2, fill=True)
        
        # Add "FACTUUR" title
        p.setFont("Helvetica-Bold", 20)
        p.setFillColor(colors.black)
        p.drawString(50, height - 50, "FACTUUR")
        
        # Add invoice details (left side)
        p.setFont("Helvetica", 10)
        y = height - 100
        p.drawString(50, y, "DATUM")
        p.drawString(250, y, "FACTUURNUMMER")
        
        y -= 15
        p.drawString(50, y, factuur.get('factuurdatum').strftime('%d-%m-%Y'))
        p.drawString(250, y, factuur.get('factuurnummer', ''))
        
        # Add company details (right side)
        p.setFont("Helvetica-Bold", 10)
        y = height - 115
        p.drawString(450, y, "SECUFY BV")
        p.setFont("Helvetica", 10)
        y -= 15
        p.drawString(450, y, "94486786")
        y -= 15
        p.drawString(450, y, "Soetendalseweg 32c")
        y -= 15
        p.drawString(450, y, "3036ER Rotterdam")
        y -= 15
        p.drawString(450, y, "0685455793")
        y -= 15
        p.drawString(450, y, "vraagje@secufy.nl")
        
        # Add client details (left side)
        y = height - 200
        p.setFont("Helvetica-Bold", 10)
        p.drawString(50, y, "FACTUUR AAN:")
        p.setFont("Helvetica", 10)
        y -= 15
        p.drawString(50, y, factuur.get('opdrachtgever_naam', ''))
        
        # Add table headers
        y = height - 300
        headers = ["UREN", "LOCATIE", "UREN", "DATUM", "TOTAAL"]
        x_positions = [50, 100, 350, 400, 500]
        p.setFont("Helvetica-Bold", 10)
        for i, header in enumerate(headers):
            p.drawString(x_positions[i], y, header)
        
        # Add "Invoice details" line
        y -= 25
        p.setFont("Helvetica", 10)
        p.drawString(50, y, "Invoice details")
        
        # Add table content with fixed rates
        y -= 20
        rates = [
            ("Day", "€20.00"),
            ("Evening", "€22.00"),
            ("Night", "€24.00"),
            ("Weekend", "€27.00"),
            ("Holiday", "€30.00"),
            ("New Year's Eve", "€40.00")
        ]
        
        total = 0
        for rate_type, rate in rates:
            hours = 0  # Get actual hours from invoice data
            if rate_type == "Night" and factuur.get('bedrag'):  # Example calculation
                hours = 1.0  # Example: 1 hour for night shift
            
            amount = hours * float(rate.replace('€', ''))
            total += amount
            
            p.drawString(50, y, f"{hours:.1f}")  # Hours
            p.drawString(100, y, f"Locatie Bleekemgraaf Toezichthouder")  # Location
            p.drawString(350, y, rate)  # Rate
            p.drawString(400, y, factuur.get('factuurdatum').strftime('%d-%m-%Y'))  # Date
            p.drawString(500, y, f"€ {amount:.2f}")  # Total
            y -= 20
        
        # Add subtotal line
        y -= 10
        p.drawString(400, y, "Subtotaal")
        p.drawString(500, y, f"€ {total:.2f}")
        
        # Add BTW
        y -= 20
        btw = total * 0.21
        p.drawString(400, y, "BTW (21%)")
        p.drawString(500, y, f"€ {btw:.2f}")
        
        # Add total
        y -= 20
        p.setFont("Helvetica-Bold", 10)
        p.drawString(400, y, "Totaal")
        p.drawString(500, y, f"€ {(total + btw):.2f}")
        
        # Add footer
        p.setFont("Helvetica", 8)
        p.drawString(50, 50, "BEDANKT VOOR UW KLANDIZIE")
        p.drawString(50, 35, "Alle bedragen gelieve over te maken op rekeningnummer NL11 ABNA 0137 7274 61")
        
        # Save the PDF
        p.showPage()
        p.save()
        
        # Reset buffer position
        buffer.seek(0)
        
        # Return the PDF as a streaming response
        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=factuur_{factuur.get('factuurnummer', factuur_id)}.pdf"
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
