"""add provincie to locations

Revision ID: add_provincie_to_locations
Revises: make_opdrachtgever_id_nullable
Create Date: 2024-03-21 10:00:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'add_provincie_to_locations'
down_revision = 'make_opdrachtgever_id_nullable'
branch_labels = None
depends_on = None

def upgrade():
    # Add provincie column to locations table
    op.add_column('locations', sa.Column('provincie', sa.String(100), nullable=True))

def downgrade():
    # Remove provincie column from locations table
    op.drop_column('locations', 'provincie') 