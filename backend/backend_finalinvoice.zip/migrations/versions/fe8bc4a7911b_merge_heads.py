"""merge heads

Revision ID: fe8bc4a7911b
Revises: 7a1b2c3d4e5f, 9f8e7d6c5b4a
Create Date: 2025-04-18 07:30:08.823271

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'fe8bc4a7911b'
down_revision = ('7a1b2c3d4e5f', '9f8e7d6c5b4a')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass 