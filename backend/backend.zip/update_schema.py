from models import update_database_schema

if __name__ == "__main__":
    print("Updating database schema...")
    update_database_schema()
    print("Database schema updated successfully!") 