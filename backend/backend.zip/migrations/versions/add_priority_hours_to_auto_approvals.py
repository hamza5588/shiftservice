"""add priority hours to auto approvals

Revision ID: add_priority_hours_to_auto_approvals
Revises: make_opdrachtgever_id_nullable
Create Date: 2025-04-12 21:51:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'add_priority_hours_to_auto_approvals'
down_revision = 'make_opdrachtgever_id_nullable'
branch_labels = None
depends_on = None

def upgrade():
    # Add priority_hours column to auto_approvals table
    op.add_column('auto_approvals', sa.Column('priority_hours', sa.Integer(), nullable=True))

def downgrade():
    # Remove priority_hours column from auto_approvals table
    op.drop_column('auto_approvals', 'priority_hours') 