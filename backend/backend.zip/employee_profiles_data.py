# employee_profiles_data.py

employee_profiles = {
    "ali": {
        "employee_id": "ali",
        "personeelsnummer": 1,
        "naam": "alikhan",
        "uurloner": True,
        "telefoonvergoeding_per_uur": 2.0,
        "maaltijdvergoeding_per_uur": 1.5,
        "de_minimis_bonus_per_uur": 0.5,
        "wkr_toeslag_per_uur": 1.0,
        "kilometervergoeding": 0.23,
        "max_km": 60,
        "hourly_allowance": 5.0
    }
    # Voeg indien nodig meer medewerkers toe...
}
